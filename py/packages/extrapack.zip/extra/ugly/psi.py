#! /usr/bin/env python3

""" example module: extra.good.psi """

def FunP():
	return "Psi"

if __name__ == "__main__":
	print("I prefer to be a module")