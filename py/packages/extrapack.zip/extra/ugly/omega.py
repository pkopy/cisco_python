#! /usr/bin/env python3

""" example module: extra.good.omega """

def FunO():
	return "Omega"

if __name__ == "__main__":
	print("I prefer to be a module")